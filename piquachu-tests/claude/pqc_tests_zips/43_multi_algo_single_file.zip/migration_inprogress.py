# Partial PQC migration: legacy RSA path retained for backward
# compatibility while new traffic is routed through ML-KEM.
# Expected verdict: mixed / transitional.
from cryptography.hazmat.primitives.asymmetric import rsa
import oqs

def legacy_encrypt_setup():
    # Old code path, still reachable for clients on API v1.
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)

def pq_encrypt_setup():
    # New code path for clients on API v2+.
    with oqs.KeyEncapsulation("ML-KEM-768") as kem:
        return kem.generate_keypair()

def get_keypair(api_version: int):
    if api_version >= 2:
        return pq_encrypt_setup()
    return legacy_encrypt_setup()
