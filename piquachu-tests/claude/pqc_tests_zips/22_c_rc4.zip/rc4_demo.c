/* Deprecated RC4 stream cipher - biased keystream, banned in TLS since 2015. */
#include <stdio.h>
#include <string.h>

void rc4_ksa(unsigned char *key, int keylen, unsigned char *S) {
    int j = 0;
    for (int i = 0; i < 256; i++) S[i] = i;
    for (int i = 0; i < 256; i++) {
        j = (j + S[i] + key[i % keylen]) % 256;
        unsigned char tmp = S[i]; S[i] = S[j]; S[j] = tmp;
    }
}

void rc4_prga(unsigned char *S, unsigned char *data, int len) {
    int i = 0, j = 0;
    for (int n = 0; n < len; n++) {
        i = (i + 1) % 256;
        j = (j + S[i]) % 256;
        unsigned char tmp = S[i]; S[i] = S[j]; S[j] = tmp;
        data[n] ^= S[(S[i] + S[j]) % 256];
    }
}

int main(void) {
    unsigned char key[] = "weakkey1";
    unsigned char S[256];
    unsigned char data[] = "top-secret-memo";
    rc4_ksa(key, 8, S);
    rc4_prga(S, data, strlen((char*)data));
    printf("RC4 keystream applied\n");
    return 0;
}
