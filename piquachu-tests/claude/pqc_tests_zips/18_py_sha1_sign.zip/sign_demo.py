# RSA signature using deprecated SHA-1 digest.
# SHA-1 is cryptographically broken (SHAttered, 2017).
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

def sign(private_key, message: bytes):
    return private_key.sign(message, padding.PKCS1v15(), hashes.SHA1())

if __name__ == "__main__":
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    sig = sign(key, b"legacy-doc")
    print("Signed with RSA+SHA1:", len(sig))
