<?php
// Deprecated DES encryption via the removed mcrypt extension.
// DES has a 56-bit key space and is trivially brute-forceable today.
$key = "8bytekey";
$iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_DES, MCRYPT_MODE_CBC), MCRYPT_RAND);
$ciphertext = mcrypt_encrypt(MCRYPT_DES, $key, "sensitive-data", MCRYPT_MODE_CBC, $iv);
echo bin2hex($ciphertext);
?>
