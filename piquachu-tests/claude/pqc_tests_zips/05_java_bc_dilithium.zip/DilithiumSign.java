// PQC digital signature demo using Dilithium via BouncyCastle PQC provider.
// Fully compliant with NIST FIPS 204 (ML-DSA).
import org.bouncycastle.pqc.jcajce.provider.BouncyCastlePQCProvider;
import java.security.*;

public class DilithiumSign {
    public static void main(String[] args) throws Exception {
        Security.addProvider(new BouncyCastlePQCProvider());
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("DILITHIUM", "BCPQC");
        KeyPair kp = kpg.generateKeyPair();

        Signature signer = Signature.getInstance("DILITHIUM", "BCPQC");
        signer.initSign(kp.getPrivate());
        signer.update("release-manifest-v4".getBytes());
        byte[] signature = signer.sign();

        Signature verifier = Signature.getInstance("DILITHIUM", "BCPQC");
        verifier.initVerify(kp.getPublic());
        verifier.update("release-manifest-v4".getBytes());
        System.out.println("Valid: " + verifier.verify(signature));
    }
}
