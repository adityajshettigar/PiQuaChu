# Backend key exchange endpoint using ML-KEM-768 (Kyber).
# Fully PQC-compliant per NIST FIPS 203.
import oqs

def handle_kem_request():
    with oqs.KeyEncapsulation("ML-KEM-768") as kem:
        pk = kem.generate_keypair()
        return pk
