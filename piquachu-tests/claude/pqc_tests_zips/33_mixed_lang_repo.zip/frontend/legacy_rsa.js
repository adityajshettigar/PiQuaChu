// Legacy frontend crypto helper still using RSA-OAEP for a payments
// widget that has not yet been migrated to the new PQC backend.
const forge = require('node-forge');

function encryptWithRsa(publicKeyPem, data) {
  const publicKey = forge.pki.publicKeyFromPem(publicKeyPem);
  return publicKey.encrypt(data, 'RSA-OAEP');
}

module.exports = { encryptWithRsa };
