// Classical elliptic-curve key generation using OpenSSL (P-256).
// NOT post-quantum safe.
#include <openssl/ec.h>
#include <openssl/obj_mac.h>
#include <iostream>

int main() {
    EC_KEY *key = EC_KEY_new_by_curve_name(NID_X9_62_prime256v1);
    EC_KEY_generate_key(key);
    std::cout << "EC P-256 key generated" << std::endl;
    EC_KEY_free(key);
    return 0;
}
