# Legacy RSA code path kept for reference but never executed.
from cryptography.hazmat.primitives.asymmetric import rsa

FEATURE_FLAG_LEGACY_CRYPTO = False

def get_keypair():
    if FEATURE_FLAG_LEGACY_CRYPTO:
        # Unreachable in current build: FEATURE_FLAG_LEGACY_CRYPTO is always False.
        return rsa.generate_private_key(public_exponent=65537, key_size=2048)
    else:
        raise NotImplementedError("PQC key generation not yet wired up")
