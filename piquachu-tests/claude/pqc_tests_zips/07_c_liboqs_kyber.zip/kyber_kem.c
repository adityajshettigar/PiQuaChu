/* Post-quantum KEM demo using Kyber768 via liboqs C API. */
/* Fully PQC-compliant per NIST FIPS 203. */
#include <oqs/oqs.h>
#include <stdio.h>
#include <stdlib.h>

int main(void) {
    OQS_KEM *kem = OQS_KEM_new(OQS_KEM_alg_kyber_768);
    uint8_t *public_key = malloc(kem->length_public_key);
    uint8_t *secret_key = malloc(kem->length_secret_key);
    uint8_t *ciphertext = malloc(kem->length_ciphertext);
    uint8_t *shared_secret_e = malloc(kem->length_shared_secret);
    uint8_t *shared_secret_d = malloc(kem->length_shared_secret);

    OQS_KEM_keypair(kem, public_key, secret_key);
    OQS_KEM_encaps(kem, ciphertext, shared_secret_e, public_key);
    OQS_KEM_decaps(kem, shared_secret_d, ciphertext, secret_key);

    printf("KEM: %s\n", kem->method_name);
    OQS_KEM_free(kem);
    return 0;
}
