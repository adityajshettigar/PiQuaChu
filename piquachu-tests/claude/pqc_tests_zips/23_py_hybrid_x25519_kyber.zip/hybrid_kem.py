# Hybrid key exchange combining classical X25519 with post-quantum ML-KEM-768.
# Transitional / defense-in-depth scheme recommended during PQC migration.
from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
import oqs

def hybrid_exchange():
    alice_x = x25519.X25519PrivateKey.generate()
    bob_x = x25519.X25519PrivateKey.generate()
    classical_secret = alice_x.exchange(bob_x.public_key())

    with oqs.KeyEncapsulation("ML-KEM-768") as kem:
        pk = kem.generate_keypair()
        ct, pqc_secret = kem.encap_secret(pk)

    combined = HKDF(algorithm=hashes.SHA384(), length=32, salt=None, info=b"hybrid-kex").derive(
        classical_secret + pqc_secret
    )
    return combined

if __name__ == "__main__":
    print("Hybrid shared secret bytes:", len(hybrid_exchange()))
