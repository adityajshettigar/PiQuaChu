// Post-quantum KEM demo using Kyber768 via the crystals-kyber package.
// Fully PQC-compliant per NIST FIPS 203 (ML-KEM).
const kyber = require('crystals-kyber');

async function exchange() {
  const { publicKey, privateKey } = kyber.keyPair();
  const { cyphertext, secret: serverSecret } = kyber.encrypt(publicKey);
  const clientSecret = kyber.decrypt(cyphertext, privateKey);
  console.log('Shared secret match:', Buffer.compare(clientSecret, serverSecret) === 0);
}

exchange();
