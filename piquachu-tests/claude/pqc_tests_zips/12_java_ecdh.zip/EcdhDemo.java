// Classical Elliptic-Curve Diffie-Hellman key agreement.
// NOT post-quantum safe.
import java.security.*;
import javax.crypto.KeyAgreement;

public class EcdhDemo {
    public static void main(String[] args) throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
        kpg.initialize(256);
        KeyPair aliceKp = kpg.generateKeyPair();
        KeyPair bobKp = kpg.generateKeyPair();

        KeyAgreement ka = KeyAgreement.getInstance("ECDH");
        ka.init(aliceKp.getPrivate());
        ka.doPhase(bobKp.getPublic(), true);
        byte[] shared = ka.generateSecret();
        System.out.println("Shared secret bytes: " + shared.length);
    }
}
