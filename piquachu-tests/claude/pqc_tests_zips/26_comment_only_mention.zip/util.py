# TODO: migrate our key exchange from RSA to a PQC KEM such as Kyber
# once the compliance team finalizes the algorithm choice.
# Ticket: SEC-4471

import os

def generate_session_token():
    # Not cryptographic key generation - just a random session id.
    return os.urandom(16).hex()
