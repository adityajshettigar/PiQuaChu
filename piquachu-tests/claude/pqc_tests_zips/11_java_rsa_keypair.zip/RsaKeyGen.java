// Classical RSA-2048 keypair generation.
// NOT post-quantum safe.
import java.security.*;

public class RsaKeyGen {
    public static void main(String[] args) throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        KeyPair kp = kpg.generateKeyPair();
        System.out.println("RSA key generated: " + kp.getPublic().getAlgorithm());
    }
}
