// Deprecated DES symmetric cipher.
import javax.crypto.*;
import javax.crypto.spec.*;

public class DesCipher {
    public static void main(String[] args) throws Exception {
        KeyGenerator kg = KeyGenerator.getInstance("DES");
        SecretKey key = kg.generateKey();
        Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] ct = cipher.doFinal("legacy-record".getBytes());
        System.out.println("Encrypted length: " + ct.length);
    }
}
