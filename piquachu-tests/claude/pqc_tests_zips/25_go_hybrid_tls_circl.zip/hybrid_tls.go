// TLS 1.3 client configured with hybrid X25519+Kyber768 key exchange
// using Cloudflare's circl/tls hybrid group support.
package main

import (
	"crypto/tls"
	"fmt"
)

func main() {
	cfg := &tls.Config{
		MinVersion: tls.VersionTLS13,
		CurvePreferences: []tls.CurveID{
			tls.X25519Kyber768Draft00,
			tls.X25519,
		},
	}
	fmt.Println("Hybrid curve preferences configured:", len(cfg.CurvePreferences))
}
