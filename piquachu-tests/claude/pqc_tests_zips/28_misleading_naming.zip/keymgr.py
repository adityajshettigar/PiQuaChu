# Function and variable names reference "rsa" for historical reasons,
# but the implementation actually generates symmetric AES key material.
# Naming left unchanged to avoid breaking downstream callers.
import os

def generate_rsa_key():
    rsa_key = os.urandom(32)  # actually an AES-256 key, not RSA
    return rsa_key

if __name__ == "__main__":
    print(len(generate_rsa_key()))
