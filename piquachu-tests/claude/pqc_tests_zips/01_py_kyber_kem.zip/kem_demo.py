# Post-Quantum KEM demo using ML-KEM-768 (Kyber) via liboqs-python.
# Fully PQC-compliant key encapsulation mechanism per NIST FIPS 203.
import oqs

def generate_and_exchange():
    kem_alg = "ML-KEM-768"
    with oqs.KeyEncapsulation(kem_alg) as client:
        public_key = client.generate_keypair()
        with oqs.KeyEncapsulation(kem_alg) as server:
            ciphertext, shared_secret_server = server.encap_secret(public_key)
        shared_secret_client = client.decap_secret(ciphertext)
        assert shared_secret_client == shared_secret_server
        return shared_secret_client

if __name__ == "__main__":
    secret = generate_and_exchange()
    print("Shared secret established via ML-KEM-768:", secret.hex()[:16])
