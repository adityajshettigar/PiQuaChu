# Import aliasing obscures the underlying algorithm name.
from cryptography.hazmat.primitives.asymmetric import rsa as pq_rsa

def generate_keypair():
    # Despite the "pq_" alias, this generates a classical RSA-3072 key.
    return pq_rsa.generate_private_key(public_exponent=65537, key_size=3072)

if __name__ == "__main__":
    key = generate_keypair()
    print(key.key_size)
