# Key Material Only

This archive contains real (but disposable, meaningless) RSA-2048 and EC P-256 key files with no accompanying source code. Tests whether the scanner inspects key/cert file headers directly, not just source code.
