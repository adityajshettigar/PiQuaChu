module kyberdemo

go 1.21

require github.com/cloudflare/circl v1.3.7
