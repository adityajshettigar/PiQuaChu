// Post-quantum KEM demo using Kyber768 via Cloudflare's circl library.
// Fully PQC-compliant per NIST FIPS 203.
package main

import (
	"fmt"
	"github.com/cloudflare/circl/kem/kyber/kyber768"
)

func main() {
	pk, sk, _ := kyber768.GenerateKeyPair(nil)
	ct, ssSender, _ := kyber768.Encapsulate(pk, nil)
	ssReceiver, _ := kyber768.Decapsulate(sk, ct)
	fmt.Println("secrets match:", string(ssSender) == string(ssReceiver))
}
