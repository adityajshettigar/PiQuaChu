// Post-quantum signature demo using Dilithium3 via the pqcrypto crate.
// Fully compliant with NIST FIPS 204 (ML-DSA).
use pqcrypto_dilithium::dilithium3::*;
use pqcrypto_traits::sign::{DetachedSignature, PublicKey, SecretKey};

fn main() {
    let (pk, sk) = keypair();
    let message = b"config-checksum-77a1";
    let sig = detached_sign(message, &sk);
    let ok = verify_detached_signature(&sig, message, &pk).is_ok();
    println!("Dilithium3 signature valid: {}", ok);
}
