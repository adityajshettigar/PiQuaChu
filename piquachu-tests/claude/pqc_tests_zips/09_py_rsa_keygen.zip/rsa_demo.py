# Classical asymmetric key generation using RSA-2048.
# NOT post-quantum safe - vulnerable to Shor's algorithm.
from cryptography.hazmat.primitives.asymmetric import rsa

def generate_rsa_keypair():
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    return private_key

if __name__ == "__main__":
    key = generate_rsa_keypair()
    print("Generated RSA-2048 key:", key.key_size)
