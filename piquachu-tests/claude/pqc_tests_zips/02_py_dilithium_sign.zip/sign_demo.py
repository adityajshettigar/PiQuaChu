# Digital signature demo using ML-DSA-65 (Dilithium3) via liboqs-python.
# Fully PQC-compliant signature scheme per NIST FIPS 204.
import oqs

message = b"Firmware update package v2.3.1"

def sign_and_verify():
    sig_alg = "Dilithium3"
    with oqs.Signature(sig_alg) as signer:
        public_key = signer.generate_keypair()
        signature = signer.sign(message)
    with oqs.Signature(sig_alg) as verifier:
        is_valid = verifier.verify(message, signature, public_key)
    return is_valid

if __name__ == "__main__":
    print("Signature valid:", sign_and_verify())
