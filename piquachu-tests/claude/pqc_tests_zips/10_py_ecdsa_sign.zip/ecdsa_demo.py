# Classical elliptic-curve signature using ECDSA over SECP256R1.
# NOT post-quantum safe - vulnerable to Shor's algorithm.
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes

def sign_message(message: bytes):
    private_key = ec.generate_private_key(ec.SECP256R1())
    signature = private_key.sign(message, ec.ECDSA(hashes.SHA256()))
    return signature

if __name__ == "__main__":
    sig = sign_message(b"invoice-4471")
    print("ECDSA signature length:", len(sig))
