# Deprecated cryptographic hash function MD5 - collision-broken since 2004.
import hashlib

def hash_password(password: str) -> str:
    return hashlib.md5(password.encode()).hexdigest()

if __name__ == "__main__":
    print(hash_password("hunter2"))
