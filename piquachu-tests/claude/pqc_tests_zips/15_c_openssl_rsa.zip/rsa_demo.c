/* Classical RSA-2048 key generation using OpenSSL. */
/* NOT post-quantum safe. */
#include <openssl/rsa.h>
#include <openssl/bn.h>
#include <stdio.h>

int main(void) {
    RSA *rsa = RSA_new();
    BIGNUM *e = BN_new();
    BN_set_word(e, RSA_F4);
    RSA_generate_key_ex(rsa, 2048, e, NULL);
    printf("RSA-2048 key generated\n");
    RSA_free(rsa);
    BN_free(e);
    return 0;
}
