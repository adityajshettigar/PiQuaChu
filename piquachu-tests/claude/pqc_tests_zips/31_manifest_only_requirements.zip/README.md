# Service Skeleton

This repository only contains dependency manifests at this stage.
No cryptographic code has been implemented yet - `pycryptodome` and
`cryptography` are listed as anticipated dependencies for an upcoming
authentication module.
