# Textbook/toy RSA implementation written from scratch without importing
# any crypto library. Tests whether a scanner does semantic detection
# (recognizing modular exponentiation + public/private exponents as RSA)
# rather than relying solely on import-statement pattern matching.

def modexp(base, exp, mod):
    result = 1
    base %= mod
    while exp > 0:
        if exp & 1:
            result = (result * base) % mod
        exp >>= 1
        base = (base * base) % mod
    return result

def toy_keygen(p, q, e=65537):
    n = p * q
    phi = (p - 1) * (q - 1)
    d = pow(e, -1, phi)
    return (e, n), (d, n)

def encrypt(m, pubkey):
    e, n = pubkey
    return modexp(m, e, n)

def decrypt(c, privkey):
    d, n = privkey
    return modexp(c, d, n)

if __name__ == "__main__":
    pub, priv = toy_keygen(61, 53)
    ct = encrypt(42, pub)
    pt = decrypt(ct, priv)
    print("Recovered:", pt)
