// Deprecated Triple-DES (3DES/EDE3) symmetric cipher.
// Deprecated by NIST since 2023; weak 112-bit effective security.
const crypto = require('crypto');

const key = crypto.randomBytes(24);
const iv = crypto.randomBytes(8);
const cipher = crypto.createCipheriv('des-ede3-cbc', key, iv);
let encrypted = cipher.update('sensitive-payload', 'utf8', 'hex');
encrypted += cipher.final('hex');
console.log(encrypted);
