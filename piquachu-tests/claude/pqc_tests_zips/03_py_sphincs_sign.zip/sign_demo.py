# Stateless hash-based signature demo using SLH-DSA (SPHINCS+) via pqcrypto.
# Fully PQC-compliant per NIST FIPS 205.
from pqcrypto.sign.sphincs_sha2_128f_simple import generate_keypair, sign, verify

def demo():
    public_key, secret_key = generate_keypair()
    message = b"contract-hash-9f8a2b"
    signature = sign(secret_key, message)
    ok = verify(message, signature, public_key)
    return ok

if __name__ == "__main__":
    print("SPHINCS+ signature valid:", demo())
