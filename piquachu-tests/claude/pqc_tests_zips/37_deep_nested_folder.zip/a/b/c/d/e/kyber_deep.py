# PQC KEM usage buried five directories deep - tests recursive scanning.
# Fully PQC-compliant per NIST FIPS 203.
import oqs

def deep_kem():
    with oqs.KeyEncapsulation("ML-KEM-1024") as kem:
        pk = kem.generate_keypair()
        return pk
