# Cython extension module performing ECDSA verification.
# NOT post-quantum safe.
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes

def verify_ecdsa(public_key, signature, message):
    public_key.verify(signature, message, ec.ECDSA(hashes.SHA256()))
    return True
