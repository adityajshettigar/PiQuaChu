// Classical RSA-2048 key generation using Go standard library.
// NOT post-quantum safe.
package main

import (
	"crypto/rand"
	"crypto/rsa"
	"fmt"
)

func main() {
	key, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		panic(err)
	}
	fmt.Println("RSA key size:", key.N.BitLen())
}
